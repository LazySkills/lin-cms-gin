/** Created By wene<354007048@qq.com> . Date at 2020/6/21 */
package lin

import (
	"github.com/astaxie/beego/validation"
	"lin-cms-gin/internal/pkg/logging"
)

// MarkErrors logs error logs
func MarkErrors(errors []*validation.Error) {
	for _, err := range errors {
		logging.Info(err.Key, err.Message)
	}

	return
}