/** Created By 嗝嗝<354007048@qq.com>. Date 2020/9/10 */
package tools


func BoolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}