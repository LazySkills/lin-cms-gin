/** Created By wene<354007048@qq.com> . Date at 2020/6/11 */
package tools

import (
	"github.com/astaxie/beego/validation"
	"lin-cms-gin/internal/pkg/logging"
)

func ValidateLog(valid validation.Validation)  {
	for _, err := range valid.Errors {
		logging.Info(err.Key, err.Message)
	}
}
